import os
import re
from typing import Optional, Tuple
import logging
from werkzeug.utils import secure_filename
from flask import Flask, render_template, request, redirect, url_for, flash
from PIL import Image
import pytesseract

class OCRConfig:
    """Configuration class for OCR application settings."""
    UPLOAD_FOLDER = 'static/uploads'
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max file size
    TESSERACT_PATH = os.getenv('TESSERACT_PATH', r'c:\Program Files\Tesseract-OCR\tesseract.exe')
    SECRET_KEY = os.urandom(24)  # Cryptographically secure random secret key
    MAX_IMAGE_SIZE = (2000, 2000)  # Max image dimensions
    MIN_OCR_CONFIDENCE = 60  # Minimum confidence threshold for OCR

class OCRProcessor:
    """Handles image processing and text extraction."""
    
    @staticmethod
    def allowed_file(filename: str) -> bool:
        """
        Check if the uploaded file has an allowed extension.
        
        Args:
            filename (str): Name of the uploaded file
        
        Returns:
            bool: True if file extension is allowed, False otherwise
        """
        return '.' in filename and \
               filename.rsplit('.', 1)[1].lower() in OCRConfig.ALLOWED_EXTENSIONS
    
    @staticmethod
    def validate_image(image_path: str) -> bool:
        """
        Validate image dimensions and size.
        
        Args:
            image_path (str): Path to the image file
        
        Returns:
            bool: True if image is valid, False otherwise
        """
        try:
            with Image.open(image_path) as img:
                # Check image dimensions
                if img.width > OCRConfig.MAX_IMAGE_SIZE[0] or \
                   img.height > OCRConfig.MAX_IMAGE_SIZE[1]:
                    logging.warning(f"Image dimensions exceed limit: {img.size}")
                    return False
                
                # Optional: Check file size (if not already done by Flask)
                file_size = os.path.getsize(image_path)
                if file_size > OCRConfig.MAX_CONTENT_LENGTH:
                    logging.warning(f"Image file size too large: {file_size} bytes")
                    return False
                
                return True
        except Exception as e:
            logging.error(f"Image validation error: {e}")
            return False
    
    @staticmethod
    def extract_text_from_image(image_path: str) -> Tuple[str, float]:
        """
        Extract text from an image and calculate accuracy.
        
        Args:
            image_path (str): Path to the image file
        
        Returns:
            Tuple containing extracted text and accuracy percentage
        """
        try:
            # Validate image before processing
            if not OCRProcessor.validate_image(image_path):
                return "Invalid image", 0.0
            
            # Configure Tesseract path
            pytesseract.pytesseract.tesseract_cmd = OCRConfig.TESSERACT_PATH
            
            # Open and preprocess image
            with Image.open(image_path) as image:
                # Enhance image for better OCR
                image = image.convert('L')  # Convert to grayscale
                image = image.resize((image.width * 2, image.height * 2), Image.LANCZOS)
                
                # Extract text with advanced configuration
                extracted_text = pytesseract.image_to_string(
                    image, 
                    lang='eng', 
                    config='--psm 6 --oem 3 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,!? '
                )
                
                # Clean and strip text
                extracted_text = extracted_text.strip()
                
                # Calculate advanced accuracy
                accuracy = OCRProcessor.calculate_advanced_accuracy(image, extracted_text)
                
                return extracted_text or "No text found in the image.", accuracy
        
        except Exception as e:
            logging.error(f"OCR Processing Error: {e}", exc_info=True)
            return f"Error processing image: {str(e)}", 0.0
    
    @staticmethod
    def calculate_advanced_accuracy(image, text: str) -> float:
        """
        Calculate advanced text extraction accuracy.
        
        Args:
            image (Image): Processed image
            text (str): Extracted text
        
        Returns:
            float: Accuracy percentage (0-100)
        """
        if not text:
            return 0.0
        
        try:
            # Advanced accuracy calculation
            # Use pytesseract's confidence data
            confidence_data = pytesseract.image_to_data(
                image, 
                output_type=pytesseract.Output.DICT, 
                lang='eng'
            )
            
            # Calculate average confidence
            confidences = [conf for conf in confidence_data['conf'] if conf != -1]
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0
            
            # Combine character validation with confidence
            total_chars = len(text)
            valid_chars = len(re.findall(r'\w', text))
            char_quality = (valid_chars / total_chars) * 100 if total_chars > 0 else 0
            
            # Weighted accuracy calculation
            accuracy = min(
                (avg_confidence * 0.6) + (char_quality * 0.4), 
                100.0
            )
            
            return round(accuracy, 2)
        
        except Exception as e:
            logging.error(f"Accuracy calculation error: {e}")
            return 0.0
    
    @staticmethod
    def save_uploaded_file(file) -> Optional[str]:
        """
        Save uploaded file securely.
        
        Args:
            file: Uploaded file object
        
        Returns:
            str: Saved filename or None if save fails
        """
        if not file:
            return None
        
        # Ensure upload directory exists
        os.makedirs(OCRConfig.UPLOAD_FOLDER, exist_ok=True)
        
        # Secure filename to prevent path traversal
        filename = secure_filename(file.filename)
        filepath = os.path.join(OCRConfig.UPLOAD_FOLDER, filename)
        
        try:
            file.save(filepath)
            return filename
        except Exception as e:
            logging.error(f"File save error: {e}", exc_info=True)
            return None

def create_app() -> Flask:
    """
    Create and configure Flask application.
    
    Returns:
        Flask: Configured Flask application
    """
    app = Flask(__name__)
    
    # Configure application
    app.config['UPLOAD_FOLDER'] = OCRConfig.UPLOAD_FOLDER
    app.config['MAX_CONTENT_LENGTH'] = OCRConfig.MAX_CONTENT_LENGTH
    app.secret_key = OCRConfig.SECRET_KEY
    
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('ocr_app.log'),
            logging.StreamHandler()
        ]
    )
    
    @app.route('/', methods=['GET', 'POST'])
    def index():
        """
        Main route for handling file upload and OCR processing.
        
        Returns:
            Rendered template with OCR results or upload form
        """
        if request.method == 'POST':
            # Check if file is present
            if 'image' not in request.files:
                flash("No file uploaded", "error")
                return redirect(request.url)
            
            file = request.files['image']
            
            # Check for empty filename
            if file.filename == '':
                flash("No selected file", "warning")
                return redirect(request.url)
            
            # Validate file
            if file and OCRProcessor.allowed_file(file.filename):
                # Save file
                filename = OCRProcessor.save_uploaded_file(file)
                
                if filename:
                    # Full path to saved image
                    filepath = os.path.join(OCRConfig.UPLOAD_FOLDER, filename)
                    
                    # Extract text
                    extracted_text, accuracy = OCRProcessor.extract_text_from_image(filepath)
                    
                    # Add logging for OCR result
                    logging.info(f"OCR processed: {filename}, Accuracy: {accuracy}%")
                    
                    return render_template(
                        'index.html',
                        uploaded_image=filename,
                        extracted_text=extracted_text,
                        accuracy=accuracy,
                        process_done=True
                    )
                else:
                    flash("Failed to save uploaded file", "error")
                    return redirect(request.url)
            else:
                flash("Invalid file type. Only images are allowed.", "error")
                return redirect(request.url)
        
        # GET request: show upload form
        return render_template('index.html', process_done=False)
    
    @app.errorhandler(413)
    def request_entity_too_large(error):
        """
        Handle file too large error.
        
        Args:
            error: Flask error object
        
        Returns:
            Rendered error template
        """
        flash("File is too large. Maximum file size is 16 MB.", "error")
        return redirect(url_for('index'))
    
    return app

# Application entry point
if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000)